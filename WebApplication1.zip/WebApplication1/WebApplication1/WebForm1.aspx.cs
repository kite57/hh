﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //string TransID = "228512006444";
            //Response.Redirect("WebForm2.aspx?TransID=" + TransID, false);


         Registration();
            
        }

        private void Registration()
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            string URL = "https://demo-ipg.comtrust.ae:2443";

            string InputJSON = "{\"Registration\":{\"Customer\":\"Demo Merchant\",\"Channel\":\"Web\",\"Amount\":\"50\",\"Currency\":\"AED\",\"OrderID\":1211123,\"OrderName\":\"Paybill\",\"OrderInfo\":null,\"TransactionHint\":\"CPT:Y;VCC:Y;\",\"UserName\":\"Demo_fY9c\",\"Password\":\"Comtrust@20182018\",\"ReturnPath\":\"http://localhost:22717/WebForm3.aspx?capture=true\"}}";
            // string InputJSON = "{\"Registration\":{\"Currency\":\"USD\",\"TransactionHint\":\"CPT: Y; VCC: Y; \",\"OrderID\":\"1211121\",\"OrderName\":\"Paybill\",\"Channel\":\"Web\",\"Amount\":\"100\",\"Customer\":\"Demo Merchant\",\"UserName\":\"Demo_fY9c\",\"Password\":\"Comtrust@20182018\",\"ReturnPath\":\"http://localhost/test1\"}}";
            try
            {
                string path = Server.MapPath("\\Demo Merchant.pfx");
                StreamWriter myWriter = null;
                X509Certificate2 certificate = new X509Certificate2(Server.MapPath("\\Demo Merchant.pfx"), "Comtrust");
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(new Uri(URL));
                byte[] lbPostBuffer = ASCIIEncoding.ASCII.GetBytes(InputJSON);
                request.ClientCertificates.Add(certificate);
                request.UserAgent = ".NET Framework Test Client";
                request.Accept = "text/xml-standard-api";
                request.Method = "POST";
                request.ContentLength = lbPostBuffer.Length;
                request.ContentType = "application/json";
                request.Timeout = 600000;
                request.ClientCertificates.Add(certificate);
                //myWriter = new StreamWriter(request.GetRequestStream());
                //myWriter.Write(InputJSON);
                HttpWebResponse response;
                Stream loPostData = request.GetRequestStream();
                loPostData.Write(lbPostBuffer, 0, lbPostBuffer.Length);
                loPostData.Close();
                response = (HttpWebResponse)request.GetResponse();
                Encoding enc = Encoding.GetEncoding(1252);
                StreamReader loResponseStream = new StreamReader(response.GetResponseStream(), enc);
                string result = loResponseStream.ReadToEnd();
                response.Close();
                loResponseStream.Close();
                result = "[" + result + "]";
                string Des = "";
                JArray Customers = JArray.Parse(result);
                string TransID = "";
                if (Customers.Count > 0)
                {
                  
                    for (int i = 0; i < Customers.Count; i++)
                    {
                        try
                        {
                            JObject objRow = JObject.Parse(Customers[i].ToString());

                           JArray Customers1 = JArray.Parse("[" + objRow["Transaction"].ToString() + "]");
                            for (int j = 0; j < Customers1.Count; j++)
                            {
                                JObject objRow1 = JObject.Parse(Customers1[j].ToString());
                                Des = (objRow1["ResponseDescription"] == null ? "" : objRow1["ResponseDescription"].ToString());
                                TransID= (objRow1["TransactionID"] == null ? "" : objRow1["TransactionID"].ToString());
                            }


                        }
                        catch (Exception ex)
                        {

                        }
                    }
                }
                if(Des == "Request Processed Successfully")
                {
                    Response.Redirect("WebForm2.aspx?TransID="+ TransID,false);

                }
                /*
                var content = new StringContent(InputJSON, Encoding.UTF8, "application/json");   
                HttpClient client = new HttpClient(new HttpClientHandler {  });
                client.BaseAddress = new Uri(URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                string result = rescontent.Result;
                Console.WriteLine(response.StatusCode);
                Console.WriteLine(result);
                */

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception :" + ex.ToString());
                Console.ReadLine();
            }
        }

        //private void Capture()
        //{
        //    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        //    string URL = "https://demo-ipg.comtrust.ae:2443";
        //    string InputJSON = "{\"Capture\":{\"Amount\":\"100\",\"Currency\":\"AED\",\"TransactionID\":\"273352566571\",\"Customer\":\"Demo Merchant\",\"UserName\":\"Demo_fY9c\",\"Password\":\"Comtrust@20182018\"}}";
        //    // string InputJSON = "{\"Registration\":{\"Currency\":\"USD\",\"TransactionHint\":\"CPT: Y; VCC: Y; \",\"OrderID\":\"1211121\",\"OrderName\":\"Paybill\",\"Channel\":\"Web\",\"Amount\":\"100\",\"Customer\":\"Demo Merchant\",\"UserName\":\"Demo_fY9c\",\"Password\":\"Comtrust@20182018\",\"ReturnPath\":\"http://localhost/test1\"}}";
        //    try
        //    {
        //        StreamWriter myWriter = null;
        //        X509Certificate2 certificate = new X509Certificate2("D:\\My Work\\WEb\\WebApplication1\\WebApplication1\\Demo Merchant.pfx", "Comtrust");
        //        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(new Uri(URL));
        //        byte[] lbPostBuffer = ASCIIEncoding.ASCII.GetBytes(InputJSON);
        //        request.ClientCertificates.Add(certificate);
        //        request.UserAgent = ".NET Framework Test Client";
        //        request.Accept = "text/xml-standard-api";
        //        request.Method = "POST";
        //        request.ContentLength = lbPostBuffer.Length;
        //        request.ContentType = "application/json";
        //        request.Timeout = 600000;
        //        request.ClientCertificates.Add(certificate);
        //        //myWriter = new StreamWriter(request.GetRequestStream());
        //        //myWriter.Write(InputJSON);
        //        HttpWebResponse response;
        //        Stream loPostData = request.GetRequestStream();
        //        loPostData.Write(lbPostBuffer, 0, lbPostBuffer.Length);
        //        loPostData.Close();
        //        response = (HttpWebResponse)request.GetResponse();
        //        Encoding enc = Encoding.GetEncoding(1252);
        //        StreamReader loResponseStream = new StreamReader(response.GetResponseStream(), enc);
        //        string result = loResponseStream.ReadToEnd();
        //        response.Close();
        //        loResponseStream.Close();
        //        Console.WriteLine(result);
        //        /*
        //        var content = new StringContent(InputJSON, Encoding.UTF8, "application/json");   
        //        HttpClient client = new HttpClient(new HttpClientHandler {  });
        //        client.BaseAddress = new Uri(URL);
        //        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        //        string result = rescontent.Result;
        //        Console.WriteLine(response.StatusCode);
        //        Console.WriteLine(result);
        //        */

        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine("Exception :" + ex.ToString());
        //        Console.ReadLine();
        //    }
        //}
        //private void Authorization()
        //{
        //    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        //    string URL = "https://demo-ipg.comtrust.ae:2443";
        //    string InputJSON = "{\"Authorization\":{\"Customer\":\"Demo Merchant\",\"Language\":\"en\",\"Currency\":\"AED\",\"Currency\":\"AED\",\"OrderID\":1211121,\"OrderName\":\"Paybill\",\"Channel\":\"W\",\"Amount\":\"100\",\"TransactionHint\":\"CPT:Y;\",\"CardNumber\":\"4111111111111111\",\"ExpiryMonth\":\"11\",\"ExpiryYear\":\"2020\",\"VerifyCode\":\"123\",\"UserName\":\"Demo_fY9c\",\"Password\":\"Comtrust@20182018\"}}";
        //    // string InputJSON = "{\"Registration\":{\"Currency\":\"USD\",\"TransactionHint\":\"CPT: Y; VCC: Y; \",\"OrderID\":\"1211121\",\"OrderName\":\"Paybill\",\"Channel\":\"Web\",\"Amount\":\"100\",\"Customer\":\"Demo Merchant\",\"UserName\":\"Demo_fY9c\",\"Password\":\"Comtrust@20182018\",\"ReturnPath\":\"http://localhost/test1\"}}";
        //    try
        //    {
        //        StreamWriter myWriter = null;
        //        X509Certificate2 certificate = new X509Certificate2("D:\\My Work\\WEb\\WebApplication1\\WebApplication1\\Demo Merchant.pfx", "Comtrust");
        //        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(new Uri(URL));
        //        byte[] lbPostBuffer = ASCIIEncoding.ASCII.GetBytes(InputJSON);
        //        request.ClientCertificates.Add(certificate);
        //        request.UserAgent = ".NET Framework Test Client";
        //        request.Accept = "text/xml-standard-api";
        //        request.Method = "POST";
        //        request.ContentLength = lbPostBuffer.Length;
        //        request.ContentType = "application/json";
        //        request.Timeout = 600000;
        //        request.ClientCertificates.Add(certificate);
        //        //myWriter = new StreamWriter(request.GetRequestStream());
        //        //myWriter.Write(InputJSON);
        //        HttpWebResponse response;
        //        Stream loPostData = request.GetRequestStream();
        //        loPostData.Write(lbPostBuffer, 0, lbPostBuffer.Length);
        //        loPostData.Close();
        //        response = (HttpWebResponse)request.GetResponse();
        //        Encoding enc = Encoding.GetEncoding(1252);
        //        StreamReader loResponseStream = new StreamReader(response.GetResponseStream(), enc);
        //        string result = loResponseStream.ReadToEnd();
        //        response.Close();
        //        loResponseStream.Close();
        //        Console.WriteLine(result);
        //        /*
        //        var content = new StringContent(InputJSON, Encoding.UTF8, "application/json");   
        //        HttpClient client = new HttpClient(new HttpClientHandler {  });
        //        client.BaseAddress = new Uri(URL);
        //        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        //        string result = rescontent.Result;
        //        Console.WriteLine(response.StatusCode);
        //        Console.WriteLine(result);
        //        */
        //        Console.ReadLine();
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine("Exception :" + ex.ToString());
        //        Console.ReadLine();
        //    }
        //}

    }
}