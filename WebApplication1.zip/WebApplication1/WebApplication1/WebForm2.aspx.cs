﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           string TransId = Request.QueryString["TransID"];
            TransactionID1.Value = TransId;


            //lblTransID.Value = TransId;
            //Hidden1.Value = TransId;
            //Response.Write ("<form id='form1' action='https://demo-ipg.comtrust.ae/PaymentEx/MerchantPay/Payment?lang=en&layout=C0BSTCBVLEI' name='buyCredits' id='buyCredits' method='post'>");
            //Response.Write("<input type='hidden' name='TransactionID' value='253735587265' />");
            //Response.Write("<input type='hidden' name='return' value='http://localhost:22717/WebForm1.aspx' />");
            //Response.Write("</form>");

            //Response.Write("<script type='text / javascript'>");
            //Response.Write("document.getElementById('buyCredits').onsubmit();");
            //Response.Write("</script>");
        }
    }
}