﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string order = Request.QueryString["capture"].ToString();
            if (order == "true")
            {
                Finalization();
             
            }
        }
        private void Finalization()
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            string URL = "https://demo-ipg.comtrust.ae:2443";
            string InputJSON = "{\"Finalization\":{\"Customer\":\"Demo Merchant\",\"TransactionID\":\"258720248737\",\"UserName\":\"Demo_fY9c\",\"Password\":\"Comtrust@20182018\"}}";
            // string InputJSON = "{\"Registration\":{\"Currency\":\"USD\",\"TransactionHint\":\"CPT: Y; VCC: Y; \",\"OrderID\":\"1211121\",\"OrderName\":\"Paybill\",\"Channel\":\"Web\",\"Amount\":\"100\",\"Customer\":\"Demo Merchant\",\"UserName\":\"Demo_fY9c\",\"Password\":\"Comtrust@20182018\",\"ReturnPath\":\"http://localhost/test1\"}}";
            try
            {
                StreamWriter myWriter = null;
                X509Certificate2 certificate = new X509Certificate2("D:\\My Work\\WEb\\WebApplication1\\WebApplication1\\Demo Merchant.pfx", "Comtrust");
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(new Uri(URL));
                byte[] lbPostBuffer = ASCIIEncoding.ASCII.GetBytes(InputJSON);
                request.ClientCertificates.Add(certificate);
                request.UserAgent = ".NET Framework Test Client";
                request.Accept = "text/xml-standard-api";
                request.Method = "POST";
                request.ContentLength = lbPostBuffer.Length;
                request.ContentType = "application/json";
                request.Timeout = 600000;
                request.ClientCertificates.Add(certificate);
                //myWriter = new StreamWriter(request.GetRequestStream());
                //myWriter.Write(InputJSON);
                HttpWebResponse response;
                Stream loPostData = request.GetRequestStream();
                loPostData.Write(lbPostBuffer, 0, lbPostBuffer.Length);
                loPostData.Close();
                response = (HttpWebResponse)request.GetResponse();
                Encoding enc = Encoding.GetEncoding(1252);
                StreamReader loResponseStream = new StreamReader(response.GetResponseStream(), enc);
                string result = loResponseStream.ReadToEnd();
                response.Close();
                loResponseStream.Close();
                string Des = "";
                result = "[" + result + "]";
                JArray Customers = JArray.Parse(result);
                if (Customers.Count > 0)
                {
                    for (int i = 0; i < Customers.Count; i++)
                    {
                        try
                        {
                            JObject objRow = JObject.Parse(Customers[i].ToString());

                            

                            JArray Customers1 = JArray.Parse("[" + objRow["Transaction"].ToString() + "]");
                            for (int j = 0; j < Customers1.Count; j++)
                            {
                                JObject objRow1 = JObject.Parse(Customers1[j].ToString());
                                Des = (objRow1["ResponseDescription"] == null ? "" : objRow1["ResponseDescription"].ToString());
                            }


                        }
                        catch (Exception ex)
                        {

                        }
                    }
                }
                if(Des== "Request processed successfully")
                {

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception :" + ex.ToString());
                Console.ReadLine();
            }
        }
    }
}